#include <iostream>
#include <iomanip>
#include <conio.h>
#include <cstdlib>
using namespace std;
class bank
{
	char name[20];
	char accounttype[20];
	int accountnumber;
	int balance;
};

int main()
{
	char name[20];
	int accountnumber;
	char accounttype[20];
	int balance;
	bank o1;
	int choice;
	bool repeat = true;
	while (repeat)
	{
		const int To_assign_initial_value = 1,
			TO_Deposit = 2,
			To_Withdraw = 3,
			TO_Display_All_Details = 4,
			Exit = 5;

		cout << "\nChoice List\n";
		cout << "---------------------" << endl;
		cout << "1.  To assign Initial Value\n";
		cout << "2.  To Deposit\n";
		cout << "3.  To Withdraw\n";
		cout << "4.  To Display All Details\n";
		cout << "5.  Exit\n";
		cout << "Enter your choice: ";
		cin >> choice;

		if (choice == To_assign_initial_value)
		{
			cout << "Enter Name: ";
			cin >> name;
			cout << "Enter Account number: ";
			cin >> accountnumber;
			cout << "Enter Account Type: ";
			cin >> accounttype;
			cout << "Enter Opening Balance: ";
			cin >> balance;
		}

		else if (choice == TO_Deposit)
		{
			cout << "Enter Deposit amount: ";
			int deposit = 0;
			cin >> deposit;
			deposit = deposit + balance;
			cout << "\nDeposit Balance = " << deposit;
			balance = deposit;
		}

		else if (choice == To_Withdraw)
		{
			int withdraw;
			cout << "\nBalance Amount = " << balance;
			cout << "\nEnter Withdraw Amount: ";
			cin >> withdraw;
			balance = balance - withdraw;
			cout << "After Withdraw Balance is " << balance;
		}

		else if (choice == TO_Display_All_Details)
		{
			cout << endl << endl << endl;
			cout << setw(50) << "Details" << endl;
			cout << "-------------------------------------" << endl;
			cout << setw(50) << "Name: " << name << endl;
			cout << setw(50) << "Account Number: " << accountnumber << endl;
			cout << setw(50) << "Account Type: " << accounttype << endl;
			cout << setw(50) << "Balance     " << balance << endl;
		}

		else if (choice == Exit)
		{
			cout << "Program ending.\n";
		}
		else
		{
			cout << "The valid choices are 1 through 5. Run the\n"
				<< "program again and select one of those.\n";
		}

		cout << "Repeat? [y/n]" << endl;
		char answer;
		cin >> answer;
		repeat = answer == 'y';
	}
	return 0;
}